# Todo Multiservice — CI/CD & Cloud Infra Automation

A **Todo / Task Manager** built with 2 independent Spring Boot microservices,
React frontend, automated with a **Jenkins CI/CD pipeline**, infrastructure
provisioned on **AWS EC2 via Terraform**, and monitored with Prometheus + Grafana.

---

## Architecture

```
React Frontend  (port 3000)
       |
       |──> Todo Service   (port 8081)  <──> PostgreSQL todo-db  (5432)
       |──> User Service   (port 8082)  <──> PostgreSQL user-db  (5433)

Prometheus (9090) scrapes both services
Grafana    (3001) visualizes Prometheus metrics
Jenkins    (8080) runs the CI/CD pipeline
```

---

## Tech Stack

| Layer          | Technology                           |
|---------------|--------------------------------------|
| Services       | Java 17, Spring Boot 3.2 (x2)        |
| Frontend       | React 18                             |
| Databases      | PostgreSQL 15 (one per service)      |
| CI/CD          | Jenkins — parallel 7-stage pipeline  |
| Containers     | Docker, Docker Compose               |
| Infra as Code  | Terraform → AWS EC2                  |
| Monitoring     | Prometheus + Grafana                 |

---

## Quick Start (Local)

```bash
git clone https://github.com/yourusername/todo-multiservice-cicd
cd todo-multiservice-cicd

docker-compose up --build -d

# URLs:
# Frontend:      http://localhost:3000
# Todo API:      http://localhost:8081/api/todos
# User API:      http://localhost:8082/api/users
# Prometheus:    http://localhost:9090
# Grafana:       http://localhost:3001  (admin / admin123)
```

---

## Cloud Infra — Terraform

```bash
cd terraform
terraform init
terraform plan
terraform apply

# Outputs:
# ec2_public_ip    = x.x.x.x
# jenkins_url      = http://x.x.x.x:8080
# frontend_url     = http://x.x.x.x:3000
# todo_service_url = http://x.x.x.x:8081
# user_service_url = http://x.x.x.x:8082
```

Terraform provisions: VPC + Subnet + IGW + Route Table + Security Group + EC2 (Ubuntu 22.04, t3.medium, 25GB).
`userdata.sh` auto-installs Docker, Docker Compose, Java 17, Maven, Node.js, and Jenkins on first boot.

---

## Jenkins CI/CD Pipeline

**Key feature: Test and Build stages run in PARALLEL for both services.**

```
Stage 1: Checkout
Stage 2: Test Services     ← parallel: Todo tests + User tests simultaneously
Stage 3: Build Services    ← parallel: Todo JAR + User JAR + Frontend build simultaneously
Stage 4: Docker Build      ← 3 images: todo-service, user-service, frontend
Stage 5: Push Images       ← Docker Hub (only on main branch)
Stage 6: Deploy to EC2     ← SSH + docker-compose up -d
Stage 7: Health Check      ← verifies BOTH services at /actuator/health
```

### Jenkins Credentials Needed

| ID                       | Type             | Value                 |
|--------------------------|------------------|-----------------------|
| `docker-hub-credentials` | Username/Password| Docker Hub login      |
| `ec2-host`               | Secret Text      | EC2 public IP         |
| `ec2-ssh-key`            | SSH private key  | Your .pem key content |

### Setup Steps

1. `terraform apply` → EC2 is ready with Jenkins auto-installed
2. Open `http://<EC2_IP>:8080` → complete Jenkins setup wizard
3. Install plugins: Git, Pipeline, Docker Pipeline, SSH Agent, JUnit
4. Add the 3 credentials above
5. New Item → Pipeline → point to `jenkins/Jenkinsfile`
6. Add GitHub webhook: `http://<EC2_IP>:8080/github-webhook/`
7. Push to main → pipeline runs automatically

---

## API Reference

### Todo Service (:8081)
| Method | Endpoint                    | Description            |
|--------|-----------------------------|------------------------|
| GET    | /api/todos                  | All todos              |
| POST   | /api/todos                  | Create todo            |
| PUT    | /api/todos/{id}             | Update todo            |
| PATCH  | /api/todos/{id}/toggle      | Toggle complete        |
| DELETE | /api/todos/{id}             | Delete todo            |
| GET    | /api/todos/user/{userId}    | Todos by user          |
| GET    | /api/todos/stats            | Count stats            |

### User Service (:8082)
| Method | Endpoint         | Description     |
|--------|------------------|-----------------|
| GET    | /api/users       | All users       |
| POST   | /api/users       | Create user     |
| PUT    | /api/users/{id}  | Update user     |
| DELETE | /api/users/{id}  | Delete user     |

---

## Project Structure

```
todo-multiservice-cicd/
├── services/
│   ├── todo-service/           # Spring Boot — Todo CRUD + stats
│   │   ├── src/main/java/com/todo/
│   │   │   ├── controller/     TodoController.java
│   │   │   ├── service/        TodoService.java
│   │   │   ├── repository/     TodoRepository.java
│   │   │   └── model/          Todo.java
│   │   └── Dockerfile
│   └── user-service/           # Spring Boot — User CRUD
│       ├── src/main/java/com/user/
│       │   ├── controller/     UserController.java
│       │   ├── service/        UserService.java
│       │   ├── repository/     UserRepository.java
│       │   └── model/          User.java
│       └── Dockerfile
├── frontend/                   # React 18 — Dashboard, Todos, Users
│   └── Dockerfile
├── jenkins/
│   └── Jenkinsfile             # 7-stage parallel CI/CD pipeline
├── terraform/
│   ├── main.tf                 # VPC, EC2, Security Group
│   ├── userdata.sh             # Bootstrap: Docker + Jenkins
│   ├── variables.tf
│   └── outputs.tf
├── monitoring/
│   ├── prometheus/prometheus.yml
│   └── grafana/datasource.yml
└── docker-compose.yml
```

---

## Interview Talking Points

**"What does multiservice CI/CD mean in your project?"**
> Two independent Spring Boot services — Todo and User — each with their own database, Dockerfile, and test suite. The Jenkins pipeline runs their tests and builds in parallel stages, so both services are tested and packaged at the same time, cutting pipeline time roughly in half.

**"How does Terraform automate cloud infrastructure?"**
> One `terraform apply` command creates the entire AWS environment: VPC, subnet, internet gateway, route table, security group, and an EC2 instance. The `userdata.sh` script runs on first boot and automatically installs Docker, Jenkins, Java — no manual SSH setup needed.

**"Why separate databases per service?"**
> That's the microservices database-per-service pattern. Todo Service owns its data, User Service owns its data. Neither can directly query the other's database. This means each service can be updated, scaled, or replaced independently without affecting the other.

**"Why parallel stages in Jenkins?"**
> Running Todo tests and User tests simultaneously cuts the pipeline duration. Instead of waiting for one to finish before starting the other, both run at the same time. Same with builds — all three (Todo JAR, User JAR, React build) run in parallel.
